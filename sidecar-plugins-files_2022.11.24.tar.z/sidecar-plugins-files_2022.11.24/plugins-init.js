(
  (
    {
      config,
    } = pipy.solve('config.js'),

    tracing = pipy.solve('tracing-init.js'),

    logger = pipy.solve('logging-init.js'),

    returns = {},

    plugins = {
      inboundL7Chains: [
        { 'INBOUND_HTTP_FIRST': [] },
        { 'INBOUND_HTTP_AFTER_TLS': ['inbound-tls-termination.js'] },
        { 'INBOUND_HTTP_AFTER_DEMUX': ['inbound-demux-http.js'] },
        { 'INBOUND_HTTP_AFTER_ROUTING': ['inbound-http-routing.js', 'metrics-http.js', 'inbound-throttle.js'] },
        { 'INBOUND_HTTP_AFTER_MUX': ['inbound-mux-http.js', 'metrics-tcp.js'] },
        { 'INBOUND_HTTP_LAST': ['inbound-proxy-tcp.js'] }
      ],
      inboundL4Chains: [
        { 'INBOUND_TCP_FIRST': [] },
        { 'INBOUND_TCP_AFTER_TLS': ['inbound-tls-termination.js'] },
        { 'INBOUND_TCP_AFTER_ROUTING': ['inbound-tcp-load-balance.js', 'metrics-tcp.js'] },
        { 'INBOUND_TCP_LAST': ['inbound-proxy-tcp.js'] }
      ],
      outboundL7Chains: [
        { 'OUTBOUND_HTTP_FIRST': [] },
        { 'OUTBOUND_HTTP_AFTER_DEMUX': ['outbound-demux-http.js'] },
        { 'OUTBOUND_HTTP_AFTER_ROUTING': ['outbound-http-routing.js', 'metrics-http.js', 'outbound-breaker.js'] },
        { 'OUTBOUND_HTTP_AFTER_MUX': ['outbound-mux-http.js', 'metrics-tcp.js'] },
        { 'OUTBOUND_HTTP_LAST': ['outbound-proxy-tcp.js'] }
      ],
      outboundL4Chains: [
        { 'OUTBOUND_TCP_FIRST': [] },
        { 'OUTBOUND_TCP_AFTER_ROUTING': ['outbound-tcp-load-balance.js', 'metrics-tcp.js'] },
        { 'OUTBOUND_TCP_LAST': ['outbound-proxy-tcp.js'] }
      ]
    },

    findChain = name => (
      ((obj = null) => (
        Object.entries(plugins).map(
          ([k, v]) => (v.map(o => o?.[name] && (obj = o?.[name])))
        ),
        obj
      ))()
    ),

    expandChains = chains => (
      ((array = []) => (
        chains.map(
          o => (
            Object.entries(o).map(
              ([k, v]) => (
                v.map(
                  c => array.push(c)
                )
              )
            )
          )
        ),
        array
      ))()
    )

  ) => (

    config?.PlugIns && (
      Object.entries(config?.PlugIns).map(
        ([k, v]) => (
          ((ch = null) => (
            ch = findChain(k),
            !ch && (
              console.log('[plugins-init] Can not find chain:', k, v)
            ),
            ch && (
              v.map(
                o => (
                  ch.push((o?.Path + '/' + o?.Entry).replaceAll('//', '/'))
                )
              )
            )
          ))()
        )
      )
    ),

    tracing.logZipkin && (
      plugins.inboundL7Chains.INBOUND_AFTER_HTTP_ROUTING.push('tracing.js'),
      plugins.outboundL7Chains.OUTBOUND_AFTER_HTTP_ROUTING.push('tracing.js')
    ),

    logger.logLogging && (
      plugins.inboundL7Chains.INBOUND_AFTER_HTTP_ROUTING.push('logging.js'),
      plugins.outboundL7Chains.OUTBOUND_AFTER_HTTP_ROUTING.push('logging.js')
    ),

    returns.inboundL7Chains = expandChains(plugins.inboundL7Chains),
    console.log('inboundL7Chains:', returns.inboundL7Chains.map(o =>
      '\n                              ->[' + o + ']').join('\n').replaceAll('\n\n', '\n')
    ),

    returns.inboundL4Chains = expandChains(plugins.inboundL4Chains),
    console.log('inboundL4Chains:', returns.inboundL4Chains.map(o =>
      '\n                              ->[' + o + ']').join('\n').replaceAll('\n\n', '\n')
    ),

    returns.outboundL7Chains = expandChains(plugins.outboundL7Chains),
    console.log('outboundL7Chains:', returns.outboundL7Chains.map(o =>
      '\n                              ->[' + o + ']').join('\n').replaceAll('\n\n', '\n')
    ),

    returns.outboundL4Chains = expandChains(plugins.outboundL4Chains),
    console.log('outboundL4Chains:', returns.outboundL4Chains.map(o =>
      '\n                              ->[' + o + ']').join('\n').replaceAll('\n\n', '\n')
    ),

    returns
  )

)()